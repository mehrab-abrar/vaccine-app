CREATE TABLE Caregiver (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Date date,
    Username varchar(255) REFERENCES Caregiver,
    PRIMARY KEY (Date, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);

CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Appointments (
    appointment_id int PRIMARY KEY,
    Date date,
    Cid varchar(255),
    Pid varchar(255),
    Vaccine_name varchar(255),
    FOREIGN KEY (Cid) REFERENCES Caregiver(Username),
    FOREIGN KEY (Pid) REFERENCES Patients(Username),
    FOREIGN KEY (Vaccine_name) REFERENCES Vaccines(Name)
);